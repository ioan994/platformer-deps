var searchData=
[
  ['zero',['Zero',['../classoxygine_1_1_color.html#a73b0c85daa3578584d235a29ef74133eaaa81ccf16815919f4936dfef0e62682e',1,'oxygine::Color']]]
];
