var searchData=
[
  ['w',['w',['../structoxygine_1_1core_1_1init__desc.html#a028860e3d1266756c5f88974cf6963ae',1,'oxygine::core::init_desc']]],
  ['white',['white',['../classoxygine_1_1_s_t_d_renderer.html#a689c58f6940afdbda4f264ef78fa9b98',1,'oxygine::STDRenderer']]]
];
