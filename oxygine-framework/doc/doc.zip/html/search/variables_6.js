var searchData=
[
  ['settings_5f',['settings_',['../class_json_1_1_char_reader_builder.html#ac69b7911ad64c171c51ebaf2ea26d958',1,'Json::CharReaderBuilder::settings_()'],['../class_json_1_1_stream_writer_builder.html#a79bdf2e639a52f4e758c0b95bd1d3423',1,'Json::StreamWriterBuilder::settings_()']]],
  ['strictroot_5f',['strictRoot_',['../class_json_1_1_features.html#a1162c37a1458adc32582b585b552f9c3',1,'Json::Features']]]
];
